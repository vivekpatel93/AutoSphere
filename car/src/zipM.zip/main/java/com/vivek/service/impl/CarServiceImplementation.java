package com.vivek.service.impl;

import com.vivek.entity.Car;
import com.vivek.exception.ResourceNotFoundException;
import com.vivek.repository.CarRepository;
import com.vivek.service.CarService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public class CarServiceImplementation implements CarService {
    @Autowired
    private CarRepository carRepository;

    @Override
    public Car save(Car car){

        return carRepository.save(car);
    }

    @Override
    public Car update(String vinNumber,Car car){
        Car c=carRepository.findById(vinNumber).orElseThrow(()->new ResourceNotFoundException("Car with given vINumber not found!, Sorry unable to update."));
        c.setCompanyName(car.getCompanyName());
        c.setCarType(car.getCarType());
        c.setModel(car.getModel());
        c.setColor(car.getColor());
        c.setPrice(car.getPrice());
        c.setSeatCapacity(car.getSeatCapacity());
        c.setMileage(car.getMileage());

        return carRepository.save(c);
    }
    @Override
    public Car findByVINumber(String vinNumber){
        return carRepository.findById(vinNumber).orElseThrow(() -> new ResourceNotFoundException("Car not found"));
    }

    @Override
    public Page<Car> findAllCar(Pageable pageable){
        return carRepository.findAll(pageable);
    }

    @Override
    public List<Car> findByCompanyName(String companyName){
        List<Car> cars = carRepository.findByCompanyName(companyName);

        if (cars.isEmpty()) {
            throw new ResourceNotFoundException(
                    "Car not found with given companyName: " + companyName);
        }

        return cars;
    }

    @Override
    public List<Car> findAllByModel(String model){
        return carRepository.findByModelName(model);
    }

    @Override
    public List<Car> findByMileageAbove20(float mileage){
        return carRepository.findByMileage(mileage);
    }

    @Override
    public List<Car> findByColor(String color){
        return carRepository.findByColor(color);
    }

    @Override
    public void delete(String vinNumber){
        Car car=carRepository.findById(vinNumber).orElseThrow(()-> new ResourceNotFoundException("Deletion can't possible."));
        carRepository.delete(car);
    }
}
