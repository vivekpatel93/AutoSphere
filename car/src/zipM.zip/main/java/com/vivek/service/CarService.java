package com.vivek.service;

import com.vivek.entity.Car;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;


import java.util.List;

public interface CarService {
    Car save(Car car);
    Car update(String vinNumber,Car car);
    Car findByVINumber(String vinNumber);
    Page<Car> findAllCar(Pageable pageable);
    List<Car> findByCompanyName(String companyName);
    List<Car> findAllByModel(String model);
    List<Car> findByMileageAbove20(float mileage);
    List<Car> findByColor(String color);
    void delete(String vinNumber);
}
