package com.vivek.controller;

import com.vivek.entity.Car;
import com.vivek.service.CarService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class CarController {
    @Autowired
    private CarService carService;

    @PostMapping("/car/save")
    public ResponseEntity<Car> registerCar(@RequestBody Car car){
        return ResponseEntity.ok(carService.save(car));
    }

    @PutMapping("/car/update")
    public ResponseEntity<Car> updateCar(@RequestParam String vinNumber, @RequestBody Car car){
        return ResponseEntity.ok(carService.update(vinNumber, car));
    }

    @GetMapping("/car/findById")
    public ResponseEntity<Car> findById(@RequestParam String vinNumber){
        return ResponseEntity.ok(carService.findByVINumber(vinNumber));
    }
    @GetMapping("/car/findAll")
    public ResponseEntity<Page<Car>> findAllCar(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue ="5") int size){
        return ResponseEntity.ok(carService.findAllCar(PageRequest.of(page,size)));
    }

    @GetMapping("/car/findCompany")
    public ResponseEntity<List<Car>> findCompany(@RequestParam String companyName){
        return ResponseEntity.ok(carService.findByCompanyName(companyName));
    }

    @GetMapping("/car/findAllByModel")
    public ResponseEntity<List<Car>>  findAllByModel(@RequestParam String model){
        return ResponseEntity.ok(carService.findAllByModel(model));
    }

    @GetMapping("/car/findByMilageabove20")
    public ResponseEntity<List<Car>> findByMilageabove20(@RequestParam float milage){
        return ResponseEntity.ok(carService.findByMileageAbove20(milage));
    }

    @GetMapping("/car/findByColor")
    public ResponseEntity<List<Car>> findByColor(@RequestParam String color){
        return ResponseEntity.ok(carService.findByColor(color));
    }

    @DeleteMapping("/car/delete")
    public ResponseEntity<Void> delete(@RequestParam String vinNumber){
        carService.delete(vinNumber);
        return ResponseEntity.noContent().build();
    }
}
